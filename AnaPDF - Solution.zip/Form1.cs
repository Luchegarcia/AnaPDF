﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;
using iText.IO.Image;
using iText.Kernel.Geom;
using iText.Kernel.Pdf;
using iText.Pdfa;
using Path = System.IO.Path;

namespace Ana_PDF_Solution
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            listView1.View = View.Details;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Multiselect = true;
            openFileDialog.Filter = "PDF and Image Files|*.pdf;*.jpg;*.jpeg;*.png;*.gif;*.bmp|All Files|*.*";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                foreach (string fileName in openFileDialog.FileNames)
                {
                    string[] row = { System.IO.Path.GetFileName(fileName), Path.GetExtension(fileName), fileName };
                    var listViewItem = new ListViewItem(row);
                    listView1.Items.Add(listViewItem);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                ListViewItem selectedItem = listView1.SelectedItems[0];
                int index = selectedItem.Index;

                if (index > 0)
                {
                    listView1.Items.RemoveAt(index);
                    listView1.Items.Insert(index - 1, selectedItem);
                    listView1.Items[index - 1].Selected = true;
                    listView1.Focus();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                ListViewItem selectedItem = listView1.SelectedItems[0];
                int index = selectedItem.Index;

                if (index < listView1.Items.Count - 1)
                {
                    listView1.Items.RemoveAt(index);
                    listView1.Items.Insert(index + 1, selectedItem);
                    listView1.Items[index + 1].Selected = true;
                    listView1.Focus();
                }
            }
        }


        private void button4_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                foreach (ListViewItem selectedItem in listView1.SelectedItems)
                {
                    listView1.Items.Remove(selectedItem);
                }
            }
        }

        private void button5_Click(object sender, EventArgs e) // Salvar
        {
            if (listView1.Items.Count > 0)
            {
                Form2 form2 = new Form2();
                form2.ShowDialog();
                string outputFileName;

                // Verificar se o usuário confirmou a entrada
                if (!string.IsNullOrEmpty(form2.FileName))
                {
                    outputFileName = form2.FileName;
                }
                else
                {
                    MessageBox.Show("Insira um Nome para o Arquivo.");
                    return;
                }

                using (var progress = new ProgressBarForm())
                {
                    progress.Show();

                    ProcessFiles(outputFileName);

                    progress.Close();
                    MessageBox.Show("Processo Concluído!");
                    Process.Start(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, outputFileName + ".pdf"));

                }

            }
            else
            {
                MessageBox.Show("Nenhum arquivo na lista para realizar a Junção.");
            }
        }

        private void ProcessFiles(string outputFileName)
        {

                List<string> fileNames = new List<string>();

                foreach (ListViewItem item in listView1.Items)
                {
                    string filePath = item.SubItems[2].Text;
                    string fileType = item.SubItems[1].Text;

                    if (fileType.Equals(".pdf", StringComparison.OrdinalIgnoreCase))
                    {
                        fileNames.Add(filePath);
                    }
                    else if (IsImageFile(fileType))
                    {
                        // Converta a imagem para PDF
                        string pdfPath = ConvertImageToPdf(filePath);
                        fileNames.Add(pdfPath);
                    }
                
                using (var mergedDocument = new PdfDocument(new PdfWriter(outputFileName + ".pdf")))
                {
                    foreach (var fileName in fileNames)
                    {
                        using (var pdfDocument = new PdfDocument(new PdfReader(fileName)))
                        {
                            pdfDocument.CopyPagesTo(1, pdfDocument.GetNumberOfPages(), mergedDocument);
                        }
                    }
                    
                }

            }
        }

        private string ConvertImageToPdf(string imagePath)
        {
            string pdfPath = Path.ChangeExtension(imagePath, ".pdf");

            // Cria um novo documento PDF para a imagem
            using (var pdfDocument = new PdfDocument(new PdfWriter(pdfPath)))
            {
                using (var document = new iText.Layout.Document(pdfDocument))
                {
                    // Adiciona a imagem ao documento PDF
                    ImageData imageData = ImageDataFactory.Create(imagePath);
                    iText.Layout.Element.Image image = new iText.Layout.Element.Image(imageData);
                    image.SetAutoScaleHeight(true);
                    document.Add(image);
                }
            }

            // Retorna o caminho do arquivo PDF gerado
            return pdfPath;
        }

        private bool IsImageFile(string fileType)
        {
            return fileType.Equals(".jpg", StringComparison.OrdinalIgnoreCase) ||
                   fileType.Equals(".jpeg", StringComparison.OrdinalIgnoreCase) ||
                   fileType.Equals(".png", StringComparison.OrdinalIgnoreCase) ||
                   fileType.Equals(".gif", StringComparison.OrdinalIgnoreCase) ||
                   fileType.Equals(".bmp", StringComparison.OrdinalIgnoreCase);
        }
    }
}